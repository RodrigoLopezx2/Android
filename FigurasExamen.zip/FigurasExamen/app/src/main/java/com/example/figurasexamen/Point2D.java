package com.example.figurasexamen;

public class Point2D{
    float f16x, f17y;
    Point2D(float x, float y) {
        this.f16x = x;
        this.f17y = y;
    }
}