package com.example.figurasexamen;

class Point3D {
    float f18x, f19y, f20z;
    Point3D(double x, double y, double z) {
        this.f18x = (float) x;
        this.f19y = (float) y;
        this.f20z = (float) z;
    }
}

